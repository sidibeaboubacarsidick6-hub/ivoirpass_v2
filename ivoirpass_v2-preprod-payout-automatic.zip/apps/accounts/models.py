"""
IvoirPass V2 — Modèle utilisateur personnalisé

Remplace le User Django par défaut.
Identifiant principal : email (pas username)
"""
from django.db import models
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin
from django.utils.translation import gettext_lazy as _
from django.utils import timezone
from django.core.exceptions import ValidationError
from .managers import CustomUserManager
from django.core.validators import FileExtensionValidator, MaxValueValidator


KYC_MAX_FILE_SIZE_MB = 5
KYC_MAX_FILE_SIZE_BYTES = KYC_MAX_FILE_SIZE_MB * 1024 * 1024


def validate_kyc_file_size(file):
    """Refuse tout fichier KYC de plus de 5 Mo (identité, domicile, pro)."""
    if file.size > KYC_MAX_FILE_SIZE_BYTES:
        raise ValidationError(
            f"Le fichier est trop volumineux ({file.size / (1024 * 1024):.1f} Mo). "
            f"Taille maximale autorisée : {KYC_MAX_FILE_SIZE_MB} Mo."
        )




class CustomUser(AbstractBaseUser, PermissionsMixin):
    """
    Modèle utilisateur IvoirPass.
    
    Rôles possibles :
    - organizer     : Organisateur d'événements / vendeur culturel
    - scanner       : Agent de contrôle d'accès (scan QR)
    - admin         : Administrateur de la plateforme
    """

    # ============================================
    # CHOIX DE RÔLES
    # ============================================
    class Role(models.TextChoices):
        ORGANIZER   = 'organizer',   _('Organisateur')
        SCANNER     = 'scanner',     _('Agent Scanner')
        ADMIN       = 'admin',       _('Administrateur')

    # ============================================
    # INFORMATIONS DE BASE
    # ============================================
    email = models.EmailField(
        _('adresse email'),
        unique=True,
        help_text="Identifiant principal de connexion"
    )
    first_name = models.CharField(
        _('prénom'),
        max_length=100,
        blank=True
    )
    last_name = models.CharField(
        _('nom de famille'),
        max_length=100,
        blank=True
    )
    phone_number = models.CharField(
        _('numéro de téléphone'),
        max_length=20,
        blank=True,
        null=True,
        help_text="Format international : +225 07 XX XX XX XX"
    )

    # ============================================
    # RÔLE ET STATUT
    # ============================================
    role = models.CharField(
        _('rôle'),
        max_length=20,
        choices=Role.choices,
        default=Role.ORGANIZER
    )
    is_active = models.BooleanField(
        _('actif'),
        default=True,
        help_text="Désactiver pour bannir un utilisateur sans supprimer son compte."
    )
    is_staff = models.BooleanField(
        _('accès admin'),
        default=False,
    )

    # ============================================
    # PROFIL
    # ============================================
    avatar = models.ImageField(
        _('photo de profil'),
        upload_to='avatars/%Y/%m/',
        blank=True,
        null=True,
    )
    bio = models.TextField(
        _('biographie'),
        blank=True,
        help_text="Utilisé pour les profils organisateurs"
    )

    # ============================================
    # VÉRIFICATION ORGANISATEUR (KYC)
    # ============================================
    is_organizer_verified = models.BooleanField(
        _('organisateur vérifié'),
        default=False,
        help_text="True quand l'admin a validé les documents KYC de l'organisateur"
    )
    organization_name = models.CharField(
        _('nom de l\'organisation'),
        max_length=200,
        blank=True,
        help_text="Nom de l'entreprise ou structure organisatrice"
    )
    organization_description = models.TextField(
        _('description de l\'organisation'),
        blank=True,
    )
    organization_logo = models.ImageField(
        _('logo de l\'organisation'),
        upload_to='logos/%Y/%m/',
        blank=True,
        null=True,
    )
    organization_website = models.URLField(
        _('site web'),
        blank=True,
    )

    # ============================================
    # KYC — DOCUMENTS
    # ============================================

    ALLOWED_KYC_EXTENSIONS = ['pdf', 'jpg', 'jpeg', 'png']

    kyc_identity_doc = models.FileField(
    _('pièce d\'identité'),
    upload_to='kyc/identity/%Y/%m/',
    null=True, blank=True,
    validators=[FileExtensionValidator(ALLOWED_KYC_EXTENSIONS), validate_kyc_file_size],
    help_text="PDF, JPG ou PNG — 5 Mo max"
    )
    kyc_proof_of_address = models.FileField(
        _('justificatif de domicile'),
        upload_to='kyc/address/%Y/%m/',
        null=True, blank=True,
        validators=[FileExtensionValidator(ALLOWED_KYC_EXTENSIONS), validate_kyc_file_size],
        help_text="Facture électricité, eau, ou attestation de domicile — PDF, JPG ou PNG, 5 Mo max"
    )
    kyc_business_doc = models.FileField(
        _('document professionnel'),
        upload_to='kyc/business/%Y/%m/',
        null=True, blank=True,
        validators=[FileExtensionValidator(ALLOWED_KYC_EXTENSIONS), validate_kyc_file_size],
        help_text="RCCM, attestation fiscale, ou déclaration d'activité — PDF, JPG ou PNG, 5 Mo max"
    )
    kyc_submitted_at = models.DateTimeField(
        _('KYC soumis le'),
        null=True, blank=True
    )
    kyc_verified_at = models.DateTimeField(
        _('KYC vérifié le'),
        null=True, blank=True
    )
    kyc_verified_by = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='kyc_verified_users',
        verbose_name=_('KYC vérifié par')
    )
    kyc_notes = models.TextField(
        _('notes KYC'),
        blank=True,
        help_text="Notes internes de l'admin sur la vérification KYC"
    )

    # ============================================
    # PRÉFÉRENCES ET LOCALISATION
    # ============================================
    city = models.CharField(
        _('ville'),
        max_length=100,
        blank=True,
        default='Abidjan',
    )
    LANGUAGE_CHOICES = [
        ('fr', 'Français'),
        ('en', 'English'),
    ]
    preferred_language = models.CharField(
        _('langue préférée'),
        max_length=5,
        choices=LANGUAGE_CHOICES,
        default='fr',
    )

    # ============================================
    # NOTIFICATIONS (préférences)
    # ============================================
    notify_email = models.BooleanField(
        _('notifications email'),
        default=True,
    )
    notify_sms = models.BooleanField(
        _('notifications SMS'),
        default=False,
    )
    notify_push = models.BooleanField(
        _('notifications push'),
        default=True,
    )

    # ============================================
    # DATES
    # ============================================
    date_joined = models.DateTimeField(
        _('date d\'inscription'),
        default=timezone.now,
    )
    last_login = models.DateTimeField(
        _('dernière connexion'),
        blank=True,
        null=True,
    )
    updated_at = models.DateTimeField(
        _('mis à jour le'),
        auto_now=True,
    )

    # ============================================
    # CONFIGURATION DU MANAGER
    # ============================================
    objects = CustomUserManager()

    # L'email remplace le username comme identifiant
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []

    class Meta:
        verbose_name = _('utilisateur')
        verbose_name_plural = _('utilisateurs')
        ordering = ['-date_joined']
        indexes = [
            models.Index(fields=['email']),
            models.Index(fields=['role']),
            models.Index(fields=['phone_number']),
        ]

    def __str__(self):
        return f"{self.get_full_name()} <{self.email}>"

    def get_full_name(self):
        full_name = f"{self.first_name} {self.last_name}".strip()
        return full_name if full_name else self.email

    def get_short_name(self):
        return self.first_name or self.email.split('@')[0]

    @property
    def is_organizer(self):
        return self.role == self.Role.ORGANIZER

    @property
    def is_scanner_agent(self):
        return self.role == self.Role.SCANNER

    @property
    def is_platform_admin(self):
        return self.role == self.Role.ADMIN

    @property
    def display_name(self):
        if self.is_organizer and self.organization_name:
            return self.organization_name
        return self.get_short_name()


class UserAddress(models.Model):
    """Adresses de livraison des utilisateurs."""
    user = models.ForeignKey(
        CustomUser,
        on_delete=models.CASCADE,
        related_name='addresses',
        verbose_name=_('utilisateur'),
    )
    label = models.CharField(_('libellé'), max_length=100, help_text="Ex: Domicile, Bureau")
    full_name = models.CharField(_('nom complet du destinataire'), max_length=200)
    phone = models.CharField(_('téléphone'), max_length=20)
    address_line1 = models.CharField(_('adresse ligne 1'), max_length=255)
    address_line2 = models.CharField(_('adresse ligne 2'), max_length=255, blank=True)
    latitude = models.DecimalField(_('latitude'), max_digits=9, decimal_places=6, null=True, blank=True)
    longitude = models.DecimalField(_('longitude'), max_digits=9, decimal_places=6, null=True, blank=True)
    city = models.CharField(_('ville'), max_length=100, default='Abidjan')
    ZONE_CHOICES = [
        ('abidjan', 'Abidjan'),
        ('grandes_villes', 'Grandes villes'),
        ('interieur', 'Intérieur du pays'),
    ]
    zone = models.CharField(_('zone de livraison'), max_length=20, choices=ZONE_CHOICES, default='abidjan')
    is_default = models.BooleanField(_('adresse par défaut'), default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = _('adresse')
        verbose_name_plural = _('adresses')
        ordering = ['-is_default', '-created_at']

    def __str__(self):
        return f"{self.label} — {self.full_name} ({self.city})"

    def save(self, *args, **kwargs):
        if self.is_default:
            UserAddress.objects.filter(user=self.user, is_default=True).exclude(pk=self.pk).update(is_default=False)
        super().save(*args, **kwargs)

    @property
    def shipping_cost(self):
        costs = {'abidjan': 1200, 'grandes_villes': 2500, 'interieur': 4000}
        return costs.get(self.zone, 1200)