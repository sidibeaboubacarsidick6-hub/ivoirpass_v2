"""
IvoirPass V2 — API Scan QR

Authentification : session Django classique (cookie), la même que
l'agent utilise pour se connecter sur scanner_app via /accounts/login/.
Pas de clé API partagée — chaque scan est attribué au vrai agent connecté.
"""
import json
import uuid as uuid_lib

from django.conf import settings
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from django.utils import timezone
from django.db import transaction
from apps.tickets.models import Ticket, GuestTicket
from apps.events.models import Event
from apps.scanner.models import ScanSession, ScanLog
from apps.dashboard.models import AuditLog
from apps.dashboard.services import log_action


def _check_agent(request):
    """Vérifie que l'utilisateur est connecté (session) et a le bon rôle."""
    user = request.user
    if not user.is_authenticated:
        return None, JsonResponse({'result': 'unauthorized', 'message': 'Session expirée, reconnectez-vous.'}, status=401)
    if not user.is_active:
        return None, JsonResponse({'result': 'unauthorized', 'message': 'Compte désactivé'}, status=403)
    if not (user.is_scanner_agent or user.is_organizer or user.is_platform_admin):
        return None, JsonResponse({'result': 'unauthorized', 'message': 'Rôle non autorisé à scanner'}, status=403)
    return user, None


@csrf_exempt
@require_POST
def scan_qr_api(request):
    """API pour scanner un QR code depuis scanner_app (session Django)."""

    agent, error_response = _check_agent(request)
    if error_response:
        return error_response

    try:
        body = json.loads(request.body)
        qr_data = body.get('qr_data', '').strip()
        event_id = body.get('event_id')
    except (json.JSONDecodeError, KeyError):
        return JsonResponse({'result': 'invalid_qr', 'message': 'Données invalides'}, status=400)

    try:
        event = Event.objects.get(pk=event_id, status='published')
    except Event.DoesNotExist:
        return JsonResponse({'result': 'wrong_event', 'message': 'Événement introuvable'})

    # Un organisateur ne peut scanner que ses propres événements.
    # Un agent scanner ne peut scanner que les événements auxquels il a
    # été explicitement assigné (Event.scanner_agents) — avant, un agent
    # scanner pouvait scanner n'importe quel événement publié sur toute
    # la plateforme, ce qui est corrigé ici.
    if agent.is_platform_admin:
        pass  # accès total
    elif agent.is_organizer:
        if event.organizer_id != agent.id:
            return JsonResponse(
                {'result': 'unauthorized', 'message': "Vous n'êtes pas l'organisateur de cet événement"},
                status=403,
            )
    else:
        if not event.scanner_agents.filter(pk=agent.id).exists():
            return JsonResponse(
                {'result': 'unauthorized', 'message': "Vous n'êtes pas assigné à cet événement"},
                status=403,
            )

    session, _ = ScanSession.objects.get_or_create(
        event=event, agent=agent,
        started_at__date=timezone.now().date(),
        defaults={'started_at': timezone.now()}
    )

    parts = qr_data.split(':')
    ticket = None
    is_guest_ticket = False
    result = None
    message = ''
    color = 'red'

    if len(parts) < 4:
        result, message, color = ScanLog.Result.INVALID_QR, "QR Code invalide", 'red'
    else:
        ticket_uuid = parts[0]
        ticket_number = parts[1]

        # Valider le format UUID avant de requêter la base
        try:
            uuid_lib.UUID(ticket_uuid)
        except (ValueError, AttributeError):
            result, message, color = ScanLog.Result.INVALID_QR, "QR Code invalide", 'red'

        if result is None:
            # Verrouillage en base le temps de la vérification + du marquage :
            # empêche deux agents de valider simultanément le même billet.
            with transaction.atomic():
                try:
                    ticket = Ticket.objects.select_for_update().select_related(
                        'order_item__ticket_type__event', 'order_item__order__buyer'
                    ).get(uuid=ticket_uuid, ticket_number=ticket_number)
                except Ticket.DoesNotExist:
                    # Un billet acheté sans compte (invité) vit dans GuestTicket,
                    # pas dans Ticket — sans ce fallback, il est toujours signalé
                    # "introuvable" alors qu'il est parfaitement valide.
                    try:
                        ticket = GuestTicket.objects.select_for_update().select_related(
                            'order_item__ticket_type__event', 'order_item__order'
                        ).get(uuid=ticket_uuid, ticket_number=ticket_number)
                        is_guest_ticket = True
                    except GuestTicket.DoesNotExist:
                        result, message, color = ScanLog.Result.NOT_FOUND, "Ticket introuvable", 'red'
                        ticket = None

                if ticket:
                    if not ticket.verify_qr(qr_data):
                        result, message, color = ScanLog.Result.INVALID_QR, "QR falsifié", 'red'
                    elif ticket.event.id != event.id:
                        result, message, color = ScanLog.Result.WRONG_EVENT, f"Ce billet est pour : {ticket.event.title}", 'orange'
                    elif ticket.status == 'void':
                        result, message, color = ScanLog.Result.TICKET_VOID, "Billet annulé", 'red'
                    elif ticket.status == 'used':
                        result, message, color = ScanLog.Result.ALREADY_USED, f"Déjà utilisé le {ticket.scanned_at.strftime('%d/%m/%Y à %H:%M')}", 'red'
                    else:
                        result, message, color = ScanLog.Result.VALID, "Accès autorisé ✅", 'green'
                        if is_guest_ticket:
                            ticket.mark_as_used()
                        else:
                            ticket.mark_as_used(scanned_by=agent)

    # ScanLog.ticket ne référence que le modèle Ticket (comptes normaux) —
    # pour un GuestTicket, la ligne n'est pas liée à un ticket précis, mais
    # le scan est bien validé et compté dans les statistiques de session.
    ScanLog.objects.create(
        session=session,
        ticket=(ticket if ticket and not is_guest_ticket else None),
        qr_data_received=qr_data[:500],
        result=result,
    )

    log_action(
        action=AuditLog.Action.TICKET_SCANNED,
        description=f"Scan billet {ticket.ticket_number if ticket else qr_data[:30]} — {result} — {event.title}",
        user=agent,
        model_name='GuestTicket' if is_guest_ticket else 'Ticket',
        object_id=ticket.ticket_number if ticket else '',
        metadata={'result': result, 'event': event.title},
    )

    session.total_scanned += 1
    if result == ScanLog.Result.VALID:
        session.total_valid += 1
    else:
        session.total_rejected += 1
    session.save(update_fields=['total_scanned', 'total_valid', 'total_rejected'])

    response_data = {'result': result, 'message': message, 'color': color}
    if ticket and result == ScanLog.Result.VALID:
        if is_guest_ticket:
            buyer_name = f"{ticket.order_item.order.first_name} {ticket.order_item.order.last_name}"
        else:
            buyer = ticket.order_item.order.buyer if ticket.order_item.order.buyer else None
            buyer_name = buyer.get_full_name() if buyer else 'Invité'
        response_data['ticket_info'] = {
            'ticket_number': ticket.ticket_number,
            'ticket_type': ticket.order_item.ticket_type.name,
            'buyer_name': buyer_name,
            'event_title': ticket.event.title,
        }

    return JsonResponse(response_data)


@csrf_exempt
@require_POST
def check_event_exists(request):
    """Vérifie si un événement existe (pour l'app scanner)."""
    try:
        body = json.loads(request.body)
        event_id = body.get('event_id')
    except (json.JSONDecodeError, KeyError):
        return JsonResponse({'exists': False})

    exists = Event.objects.filter(pk=event_id, status='published').exists()
    return JsonResponse({'exists': exists})